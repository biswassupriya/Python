# -*- coding: utf-8 -*-
"""
Created on Fri Oct 25 13:12:40 2019

@author: Supi
"""

class Library:
    def __init__(self):
        self.libraryResources = []
        self.lBook = []
        self.eBook = []
        
    def setlibraryResources(self,r):
        self.libraryResources = r
        """
       
       """
    
    def getlibraryResources(self):
        return self.libraryResources
        
    def setlBook(self,b):
        self.lBook = b
        """
       
       """
    
    def getlBook(self):
        return self.lBook
    
    def seteBook(self,ebook):
        self.eBook = ebook
        """
       
       """
    
    def geteBook(self):
        return self.eBook
    

    def getcheckLibraryResources(self):
        if self.libraryResources is None:
            return True
        else:
            return False
        
    def geteditResource(self):
         if self.eResource is None:
             print("add new title:")
         else:
            print("resource not in catalogue")
            
            
    def getaddSearchBook(self):
         if self.eResource in None:
             print("contain in catalogue")
         else:
            print("None")
               
    def getprintsearchcatalogue(self,Isbn):
	     print("detail resources of Isbn")
	     if resource is catalouge:
	       print("total amount of resources found")
	     else:
	       print("resource not in catalogue") 
         else:
           print("resource is an electronic resource")   
        
        
    
    