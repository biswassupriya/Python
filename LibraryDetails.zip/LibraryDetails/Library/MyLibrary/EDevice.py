# -*- coding: utf-8 -*-
"""
Created on Thu Oct 24 11:14:37 2019

@author: Supi
"""


class EDevice:
    """
    class represent a Eletronic Device
    """

    def __init__(self):
        self.eDeviceId = 0
        self.eDeviceName = ""
        self.eDeviceLocation = ""
        self.eDeviceAvailable = True

        """
        data fields attributes for the class EDevice 
        """

    def setEDeviceId(self, eDeviceId):
        self.eDeviceId = eDeviceId

    def getEDeviceId(self):
        return self.eDeviceId

    def setEDeviceName(self, eDeviceName):
        self.eDeviceName = eDeviceName

    def getEDeviceName(self):
        return self.eDeviceName

    def setEDeviceLocation(self, eDeviceLocation):
        self.eDeviceLocation = eDeviceLocation

    def getEDeviceLocation(self):
        return self.eDeviceLocation

    def setEDeviceAvailable(self, eDeviceAvailable):
        self.eDeviceAvailable = eDeviceAvailable

    def isEDeviceAvailable(self, eDeviceId):
        if self.eDeviceId == eDeviceId:
            return self.eDeviceAvailable
        else:
            return False

    def getEDeviceDetailsByEDeviceId(self, eDeviceId):
        if self.eDeviceId == eDeviceId:
            return "eDeviceId: " + str(self.getEDeviceId()) + ", eDeviceName: " + self.getEDeviceName() \
                   + ", eDeviceLocation: " + self.getEDeviceLocation() + ", eDevice Availability: " + ("Not Available","Available")[self.isEDeviceAvailable(eDeviceId)]
                  # "Available" if self.isEDeviceAvailable(eDeviceId) else "Not Available"

        else:
            return "eDeviceId: {} not Found".format(eDeviceId)
