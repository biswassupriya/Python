# -*- coding: utf-8 -*-
"""
Created on Sat Oct 12 01:20:56 2019

@author: Supi
"""

class Variable:
       pass
   
    x= 0
    y=1
        
   
    print(x+y)